package pages;

public interface CommonTestingType {

    boolean isPresent();
}
